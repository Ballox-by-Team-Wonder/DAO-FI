# Start React Free - Multipurpose Admin Dashboard Template

- For a quick start please check [Online documentation](//preview.keenthemes.com/start-react-free/docs/quick-start)

- To learn more about the product license, please check out LICENSE file or [Product Licenses](//keenthemes.com/licensing)

- Check out our market for more products: [Keenthemes Market](//keenthemes.com)

- For more amazing features and solutions, please upgrade to [{{$product.name-pro}}](//keenthemes.com/products/start-react-pro)

- Stay tuned for updates via [Twitter](//www.twitter.com/keenthemes), [Instagram](//www.instagram.com/keenthemes), [Dribbble](//dribbble.com/keenthemes) and [Facebook](//facebook.com/keenthemes)

Happy coding with Start React Free!
