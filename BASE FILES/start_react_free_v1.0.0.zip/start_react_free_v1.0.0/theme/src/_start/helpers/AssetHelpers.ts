export const toAbsoluteUrl = (pathname: string) => process.env.PUBLIC_URL + pathname;
