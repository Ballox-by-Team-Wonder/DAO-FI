// import { DList } from "./IconModels";

// export const StockholmIconList: Array<DList> = [
//   {
//     name: "Clothes",
//     items: [
//       {
//         name: "Brassiere.svg",
//         path: "/media/icons/stockholm/Clothes/Brassiere.svg",
//       },
//       {
//         name: "Briefcase.svg",
//         path: "/media/icons/stockholm/Clothes/Briefcase.svg",
//       },
//       {
//         name: "Cap.svg",
//         path: "/media/icons/stockholm/Clothes/Cap.svg",
//       },
//       {
//         name: "Crown.svg",
//         path: "/media/icons/stockholm/Clothes/Crown.svg",
//       },
//       {
//         name: "Dress.svg",
//         path: "/media/icons/stockholm/Clothes/Dress.svg",
//       },
//       {
//         name: "Hanger.svg",
//         path: "/media/icons/stockholm/Clothes/Hanger.svg",
//       },
//       {
//         name: "Hat.svg",
//         path: "/media/icons/stockholm/Clothes/Hat.svg",
//       },
//       {
//         name: "Panties.svg",
//         path: "/media/icons/stockholm/Clothes/Panties.svg",
//       },
//       {
//         name: "Shirt.svg",
//         path: "/media/icons/stockholm/Clothes/Shirt.svg",
//       },
//       {
//         name: "Shoes.svg",
//         path: "/media/icons/stockholm/Clothes/Shoes.svg",
//       },
//       {
//         name: "Shorts.svg",
//         path: "/media/icons/stockholm/Clothes/Shorts.svg",
//       },
//       {
//         name: "Sneakers.svg",
//         path: "/media/icons/stockholm/Clothes/Sneakers.svg",
//       },
//       {
//         name: "Socks.svg",
//         path: "/media/icons/stockholm/Clothes/Socks.svg",
//       },
//       {
//         name: "Sun-glasses.svg",
//         path: "/media/icons/stockholm/Clothes/Sun-glasses.svg",
//       },
//       {
//         name: "T-Shirt.svg",
//         path: "/media/icons/stockholm/Clothes/T-Shirt.svg",
//       },
//       {
//         name: "Tie.svg",
//         path: "/media/icons/stockholm/Clothes/Tie.svg",
//       },
//     ],
//   },
//   {
//     name: "Code",
//     items: [
//       {
//         name: "Backspace.svg",
//         path: "/media/icons/stockholm/Code/Backspace.svg",
//       },
//       {
//         name: "CMD.svg",
//         path: "/media/icons/stockholm/Code/CMD.svg",
//       },
//       {
//         name: "Code.svg",
//         path: "/media/icons/stockholm/Code/Code.svg",
//       },
//       {
//         name: "Commit.svg",
//         path: "/media/icons/stockholm/Code/Commit.svg",
//       },
//       {
//         name: "Compiling.svg",
//         path: "/media/icons/stockholm/Code/Compiling.svg",
//       },
//       {
//         name: "Control.svg",
//         path: "/media/icons/stockholm/Code/Control.svg",
//       },
//       {
//         name: "Done-circle.svg",
//         path: "/media/icons/stockholm/Code/Done-circle.svg",
//       },
//       {
//         name: "Error-circle.svg",
//         path: "/media/icons/stockholm/Code/Error-circle.svg",
//       },
//       {
//         name: "Git1.svg",
//         path: "/media/icons/stockholm/Code/Git1.svg",
//       },
//       {
//         name: "Git2.svg",
//         path: "/media/icons/stockholm/Code/Git2.svg",
//       },
//       {
//         name: "Git3.svg",
//         path: "/media/icons/stockholm/Code/Git3.svg",
//       },
//       {
//         name: "Git4.svg",
//         path: "/media/icons/stockholm/Code/Git4.svg",
//       },
//       {
//         name: "Github.svg",
//         path: "/media/icons/stockholm/Code/Github.svg",
//       },
//       {
//         name: "Info-circle.svg",
//         path: "/media/icons/stockholm/Code/Info-circle.svg",
//       },
//       {
//         name: "Left-circle.svg",
//         path: "/media/icons/stockholm/Code/Left-cirlce.svg",
//       },
//       {
//         name: "Loading.svg",
//         path: "/media/icons/stockholm/Code/Loading.svg",
//       },
//       {
//         name: "Lock-circle.svg",
//         path: "/media/icons/stockholm/Code/Lock-cicle.svg",
//       },
//       {
//         name: "Lock-overturning.svg",
//         path: "/media/icons/stockholm/Code/Lock-overturning.svg",
//       },
//       {
//         name: "Minus.svg",
//         path: "/media/icons/stockholm/Code/Minus.svg",
//       },
//       {
//         name: "Option.svg",
//         path: "/media/icons/stockholm/Code/Option.svg",
//       },
//       {
//         name: "Plus.svg",
//         path: "/media/icons/stockholm/Code/Plus.svg",
//       },
//       {
//         name: "Puzzle.svg",
//         path: "/media/icons/stockholm/Code/Puzzle.svg",
//       },
//       {
//         name: "Quistion-circle.svg",
//         path: "/media/icons/stockholm/Code/Quistion-circle.svg",
//       },
//       {
//         name: "Right-circle.svg",
//         path: "/media/icons/stockholm/Code/Right-circle.svg",
//       },
//       {
//         name: "Settings4.svg",
//         path: "/media/icons/stockholm/Code/Settings4.svg",
//       },
//       {
//         name: "Shift.svg",
//         path: "/media/icons/stockholm/Code/Shift.svg",
//       },
//       {
//         name: "Spy.svg",
//         path: "/media/icons/stockholm/Code/Spy.svg",
//       },
//       {
//         name: "Stop.svg",
//         path: "/media/icons/stockholm/Code/Stop.svg",
//       },
//       {
//         name: "Terminal.svg",
//         path: "/media/icons/stockholm/Code/Terminal.svg",
//       },
//       {
//         name: "Terminal.svg",
//         path: "/media/icons/stockholm/Code/Terminal.svg",
//       },
//       {
//         name: "Thunder-circle.svg",
//         path: "/media/icons/stockholm/Code/Thunder-circle.svg",
//       },
//       {
//         name: "Time-schedule.svg",
//         path: "/media/icons/stockholm/Code/Time-schedule.svg",
//       },
//       {
//         name: "Warning-1-circle.svg",
//         path: "/media/icons/stockholm/Code/Warning-1-circle.svg",
//       },
//       {
//         name: "Warning-2.svg",
//         path: "/media/icons/stockholm/Code/Warning-2.svg",
//       },
//     ],
//   },
//   {
//     name: "Communication",
//     items: [
//       {
//         name: "Active-call.svg",
//         path: "/media/icons/stockholm/Communication/Active-call.svg",
//       },
//       {
//         name: "Add-user.svg",
//         path: "/media/icons/stockholm/Communication/Add-user.svg",
//       },
//       {
//         name: "Address-card.svg",
//         path: "/media/icons/stockholm/Communication/Address-card.svg",
//       },
//       // {
//       //   name: "Address-book1.svg",
//       //   path: "/media/icons/stockholm/Communication/Address-book1.svg",
//       // },
//       // {
//       //   name: "Address-book2.svg",
//       //   path: "/media/icons/stockholm/Communication/Address-book2.svg",
//       // },
//       {
//         name: "Archive.svg",
//         path: "/media/icons/stockholm/Communication/Archive.svg",
//       },
//       {
//         name: "Call.svg",
//         path: "/media/icons/stockholm/Communication/Call.svg",
//       },
//       // {
//       //   name: "Call#1.svg",
//       //   path: "/media/icons/stockholm/Communication/Call#1.svg",
//       // },
//       {
//         name: "Chat-check.svg",
//         path: "/media/icons/stockholm/Communication/Chat-check.svg",
//       },
//       {
//         name: "Chat-error.svg",
//         path: "/media/icons/stockholm/Communication/Chat-error.svg",
//       },
//       {
//         name: "Chat-locked.svg",
//         path: "/media/icons/stockholm/Communication/Chat-locked.svg",
//       },
//       {
//         name: "Chat-smile.svg",
//         path: "/media/icons/stockholm/Communication/Chat-smile.svg",
//       },
//       {
//         name: "Chat1.svg",
//         path: "/media/icons/stockholm/Communication/Chat1.svg",
//       },
//       {
//         name: "Chat2.svg",
//         path: "/media/icons/stockholm/Communication/Chat2.svg",
//       },
//       {
//         name: "Chat4.svg",
//         path: "/media/icons/stockholm/Communication/Chat4.svg",
//       },
//       {
//         name: "Chat5.svg",
//         path: "/media/icons/stockholm/Communication/Chat5.svg",
//       },
//       {
//         name: "Chat6.svg",
//         path: "/media/icons/stockholm/Communication/Chat6.svg",
//       },
//       // {
//       //   name: "Clipboard-check.svg",
//       //   path: "/media/icons/stockholm/Communication/Clipboard-clip.svg",
//       // },
//       {
//         name: "Clipboard-list.svg",
//         path: "/media/icons/stockholm/Communication/Clipboard-list.svg",
//       },
//       {
//         name: "Contact1.svg",
//         path: "/media/icons/stockholm/Communication/Contact1.svg",
//       },
//       {
//         name: "Delete-user.svg",
//         path: "/media/icons/stockholm/Communication/Delete-user.svg",
//       },
//       {
//         name: "Chat2.svg",
//         path: "/media/icons/stockholm/Communication/Chat2.svg",
//       },
//       {
//         name: "Dial-numbers.svg",
//         path: "/media/icons/stockholm/Communication/Dial-numbers.svg",
//       },
//       {
//         name: "Flag.svg",
//         path: "/media/icons/stockholm/Communication/Flag.svg",
//       },
//       {
//         name: "Forward.svg",
//         path: "/media/icons/stockholm/Communication/Forward.svg",
//       },
//       {
//         name: "Group-chat.svg",
//         path: "/media/icons/stockholm/Communication/Group-chat.svg",
//       },
//       {
//         name: "Group.svg",
//         path: "/media/icons/stockholm/Communication/Group.svg",
//       },
//       {
//         name: "Incoming-box.svg",
//         path: "/media/icons/stockholm/Communication/Incoming-box.svg",
//       },
//       {
//         name: "Incoming-call.svg",
//         path: "/media/icons/stockholm/Communication/Incoming-call.svg",
//       },
//       {
//         name: "Incoming-mail.svg",
//         path: "/media/icons/stockholm/Communication/Incoming-mail.svg",
//       },
//       {
//         name: "Mail-at.svg",
//         path: "/media/icons/stockholm/Communication/Mail-at.svg",
//       },
//       {
//         name: "Mail-attachment.svg",
//         path: "/media/icons/stockholm/Communication/Mail-attachment.svg",
//       },
//       {
//         name: "Mail-box.svg",
//         path: "/media/icons/stockholm/Communication/Mail-box.svg",
//       },
//       {
//         name: "Mail-error.svg",
//         path: "/media/icons/stockholm/Communication/Mail-error.svg",
//       },
//       {
//         name: "Mail-heart.svg",
//         path: "/media/icons/stockholm/Communication/Mail-heart.svg",
//       },
//       {
//         name: "Mail-locked.svg",
//         path: "/media/icons/stockholm/Communication/Mail-locked.svg",
//       },
//       {
//         name: "Mail-notification.svg",
//         path: "/media/icons/stockholm/Communication/Mail-notification.svg",
//       },
//       {
//         name: "Mail-opened.svg",
//         path: "/media/icons/stockholm/Communication/Mail-opened.svg",
//       },
//       {
//         name: "Mail-unlocked.svg",
//         path: "/media/icons/stockholm/Communication/Mail-unlocked.svg",
//       },
//       {
//         name: "Mail.svg",
//         path: "/media/icons/stockholm/Communication/Mail.svg",
//       },
//       {
//         name: "Missed-call.svg",
//         path: "/media/icons/stockholm/Communication/Missed-call.svg",
//       },
//       {
//         name: "Outgoing-box.svg",
//         path: "/media/icons/stockholm/Communication/Outgoing-box.svg",
//       },
//       {
//         name: "Readed-mail.svg",
//         path: "/media/icons/stockholm/Communication/Readed-mail.svg",
//       },
//       {
//         name: "Reply-all.svg",
//         path: "/media/icons/stockholm/Communication/Reply-all.svg",
//       },
//       {
//         name: "Reply.svg",
//         path: "/media/icons/stockholm/Communication/Reply.svg",
//       },
//       {
//         name: "Right.svg",
//         path: "/media/icons/stockholm/Communication/Right.svg",
//       },
//       {
//         name: "RSS.svg",
//         path: "/media/icons/stockholm/Communication/RSS.svg",
//       },
//       {
//         name: "Safe-chat.svg",
//         path: "/media/icons/stockholm/Communication/Safe-chat.svg",
//       },
//       {
//         name: "Send.svg",
//         path: "/media/icons/stockholm/Communication/Send.svg",
//       },
//       {
//         name: "Sending mail.svg",
//         path: "/media/icons/stockholm/Communication/Sending mail.svg",
//       },
//       {
//         name: "Sending.svg",
//         path: "/media/icons/stockholm/Communication/Sending.svg",
//       },
//       {
//         name: "Share.svg",
//         path: "/media/icons/stockholm/Communication/Share.svg",
//       },
//       {
//         name: "Shield-thunder.svg",
//         path: "/media/icons/stockholm/Communication/Shield-thunder.svg",
//       },
//       {
//         name: "Snoozed-mail.svg",
//         path: "/media/icons/stockholm/Communication/Snoozed-mail.svg",
//       },
//       {
//         name: "Spam.svg",
//         path: "/media/icons/stockholm/Communication/Spam.svg",
//       },
//       {
//         name: "Thumbtack.svg",
//         path: "/media/icons/stockholm/Communication/Thumbtack.svg",
//       },
//       {
//         name: "Urgent-mail.svg",
//         path: "/media/icons/stockholm/Communication/Urgent-mail.svg",
//       },
//       {
//         name: "Write.svg",
//         path: "/media/icons/stockholm/Communication/Write.svg",
//       },
//     ],
//   },
//   {
//     name: "Cooking",
//     items: [
//       {
//         name: "Baking-glove.svg",
//         path: "/media/icons/stockholm/Cooking/Baking-glove.svg",
//       },
//       {
//         name: "Bowl.svg",
//         path: "/media/icons/stockholm/Cooking/Bowl.svg",
//       },
//       {
//         name: "Chef.svg",
//         path: "/media/icons/stockholm/Cooking/Chef.svg",
//       },
//       {
//         name: "Cooking-book.svg",
//         path: "/media/icons/stockholm/Cooking/Cooking-book.svg",
//       },
//       {
//         name: "Cooking-pot.svg",
//         path: "/media/icons/stockholm/Cooking/Cooking-pot.svg",
//       },
//       {
//         name: "Cutting board.svg",
//         path: "/media/icons/stockholm/Cooking/Cutting board.svg",
//       },
//       {
//         name: "Dinner.svg",
//         path: "/media/icons/stockholm/Cooking/Dinner.svg",
//       },
//       {
//         name: "Dish.svg",
//         path: "/media/icons/stockholm/Cooking/Dish.svg",
//       },
//       {
//         name: "Dishes.svg",
//         path: "/media/icons/stockholm/Cooking/Dishes.svg",
//       },
//       {
//         name: "Fork-spoon-knife.svg",
//         path: "/media/icons/stockholm/Cooking/Fork-spoon-knife.svg",
//       },
//       {
//         name: "Fork-spoon.svg",
//         path: "/media/icons/stockholm/Cooking/Fork-spoon.svg",
//       },
//       {
//         name: "Fork.svg",
//         path: "/media/icons/stockholm/Cooking/Fork.svg",
//       },
//       {
//         name: "Frying-pan.svg",
//         path: "/media/icons/stockholm/Cooking/Frying-pan.svg",
//       },
//       {
//         name: "Grater.svg",
//         path: "/media/icons/stockholm/Cooking/Grater.svg",
//       },
//       {
//         name: "Kitchen-scale.svg",
//         path: "/media/icons/stockholm/Cooking/Kitchen-scale.svg",
//       },
//       {
//         name: "Knife1.svg",
//         path: "/media/icons/stockholm/Cooking/Knife1.svg",
//       },
//       {
//         name: "Knife2.svg",
//         path: "/media/icons/stockholm/Cooking/Knife2.svg",
//       },
//       {
//         name: "KnifeAndFork1.svg",
//         path: "/media/icons/stockholm/Cooking/KnifeAndFork1.svg",
//       },
//       {
//         name: "KnifeAndFork2.svg",
//         path: "/media/icons/stockholm/Cooking/KnifeAndFork2.svg",
//       },
//       {
//         name: "Ladle.svg",
//         path: "/media/icons/stockholm/Cooking/Ladle.svg",
//       },
//       {
//         name: "Rolling-pin.svg",
//         path: "/media/icons/stockholm/Cooking/Rolling-pin.svg",
//       },
//       {
//         name: "Spoon.svg",
//         path: "/media/icons/stockholm/Cooking/Spoon.svg",
//       },
//       {
//         name: "Soucepan.svg",
//         path: "/media/icons/stockholm/Cooking/Soucepan.svg",
//       },
//       {
//         name: "Shovel.svg",
//         path: "/media/icons/stockholm/Cooking/Shovel.svg",
//       },
//       {
//         name: "Sieve.svg",
//         path: "/media/icons/stockholm/Cooking/Sieve.svg",
//       },
//     ],
//   },
//   {
//     name: "Design",
//     items: [
//       {
//         name: "Adjust.svg",
//         path: "/media/icons/stockholm/Design/Adjust.svg",
//       },
//       {
//         name: "Anchor-center-down.svg",
//         path: "/media/icons/stockholm/Design/Anchor-center-down.svg",
//       },
//       {
//         name: "Anchor-center-up.svg",
//         path: "/media/icons/stockholm/Design/Anchor-center-up.svg",
//       },
//       {
//         name: "Anchor-center.svg",
//         path: "/media/icons/stockholm/Design/Anchor-cnter.svg",
//       },
//       {
//         name: "Anchor-left-down.svg",
//         path: "/media/icons/stockholm/Design/Anchor-left-down.svg",
//       },
//       {
//         name: "Anchor-left-up.svg",
//         path: "/media/icons/stockholm/Design/Anchor-left-up.svg",
//       },
//       {
//         name: "Anchor-right-down.svg",
//         path: "/media/icons/stockholm/Design/Anchor-right-down.svg",
//       },
//       {
//         name: "Anchor-right-up.svg",
//         path: "/media/icons/stockholm/Design/Anchor-right-up.svg",
//       },
//       {
//         name: "Anchor-right.svg",
//         path: "/media/icons/stockholm/Design/Anchor-right.svg",
//       },
//       {
//         name: "Arrows.svg",
//         path: "/media/icons/stockholm/Design/Arrows.svg",
//       },
//       {
//         name: "Bezier-curve.svg",
//         path: "/media/icons/stockholm/Design/Bezier-curve.svg",
//       },
//       {
//         name: "Border.svg",
//         path: "/media/icons/stockholm/Design/Border.svg",
//       },
//       {
//         name: "Brush.svg",
//         path: "/media/icons/stockholm/Design/Brush.svg",
//       },
//       {
//         name: "Bucket.svg",
//         path: "/media/icons/stockholm/Design/Bucket.svg",
//       },
//       {
//         name: "Cap-1.svg",
//         path: "/media/icons/stockholm/Design/Cap-1.svg",
//       },
//       {
//         name: "Cap-2.svg",
//         path: "/media/icons/stockholm/Design/Cap-2.svg",
//       },
//       {
//         name: "Cap-3.svg",
//         path: "/media/icons/stockholm/Design/Cap-3.svg",
//       },
//       {
//         name: "Circle.svg",
//         path: "/media/icons/stockholm/Design/Circle.svg",
//       },
//       {
//         name: "Color-profile.svg",
//         path: "/media/icons/stockholm/Design/Color-profile.svg",
//       },
//       {
//         name: "Color.svg",
//         path: "/media/icons/stockholm/Design/Color.svg",
//       },
//       {
//         name: "Component.svg",
//         path: "/media/icons/stockholm/Design/Component.svg",
//       },
//       {
//         name: "Crop.svg",
//         path: "/media/icons/stockholm/Design/Crop.svg",
//       },
//       {
//         name: "Difference.svg",
//         path: "/media/icons/stockholm/Design/Difference.svg",
//       },
//       {
//         name: "Edit.svg",
//         path: "/media/icons/stockholm/Design/Edit.svg",
//       },
//       {
//         name: "Eraser.svg",
//         path: "/media/icons/stockholm/Design/Eraser.svg",
//       },
//       {
//         name: "Flatten.svg",
//         path: "/media/icons/stockholm/Design/Flatten.svg",
//       },
//       {
//         name: "Flip-horiontal.svg",
//         path: "/media/icons/stockholm/Design/Flip-horizontal.svg",
//       },
//       {
//         name: "Flip-vertical.svg",
//         path: "/media/icons/stockholm/Design/Flip-vertical.svg",
//       },
//       {
//         name: "Horizontal.svg",
//         path: "/media/icons/stockholm/Design/Horizontal.svg",
//       },
//       {
//         name: "Image.svg",
//         path: "/media/icons/stockholm/Design/Image.svg",
//       },
//       {
//         name: "Interselect.svg",
//         path: "/media/icons/stockholm/Design/Interselect.svg",
//       },
//       {
//         name: "Join-1.svg",
//         path: "/media/icons/stockholm/Design/Join-1.svg",
//       },
//       {
//         name: "Join-2.svg",
//         path: "/media/icons/stockholm/Design/Join-2.svg",
//       },
//       {
//         name: "Join-3.svg",
//         path: "/media/icons/stockholm/Design/Join-3.svg",
//       },
//       {
//         name: "Layers.svg",
//         path: "/media/icons/stockholm/Design/Layers.svg",
//       },
//       {
//         name: "Line.svg",
//         path: "/media/icons/stockholm/Design/Line.svg",
//       },
//       {
//         name: "Magic.svg",
//         path: "/media/icons/stockholm/Design/Magic.svg",
//       },
//       {
//         name: "Mask.svg",
//         path: "/media/icons/stockholm/Design/Mask.svg",
//       },
//       {
//         name: "Patch.svg",
//         path: "/media/icons/stockholm/Design/Patch.svg",
//       },
//       {
//         name: "Pen-tool-vector.svg",
//         path: "/media/icons/stockholm/Design/Pen-tool-vector.svg",
//       },
//       {
//         name: "PenAndRuller.svg",
//         path: "/media/icons/stockholm/Design/PenAndRuller",
//       },
//       {
//         name: "Pencil.svg",
//         path: "/media/icons/stockholm/Design/Pencil.svg",
//       },
//       {
//         name: "Picker.svg",
//         path: "/media/icons/stockholm/Design/Picker.svg",
//       },
//       {
//         name: "Pixels.svg",
//         path: "/media/icons/stockholm/Design/Pixels.svg",
//       },
//       {
//         name: "Polygon.svg",
//         path: "/media/icons/stockholm/Design/Polygon.svg",
//       },
//       {
//         name: "Position.svg",
//         path: "/media/icons/stockholm/Design/Position.svg",
//       },
//       {
//         name: "Rectangle.svg",
//         path: "/media/icons/stockholm/Design/Rectangle.svg",
//       },
//       {
//         name: "Saturation.svg",
//         path: "/media/icons/stockholm/Design/Saturation.svg",
//       },
//       {
//         name: "Select.svg",
//         path: "/media/icons/stockholm/Design/Select.svg",
//       },
//       {
//         name: "Sketch.svg",
//         path: "/media/icons/stockholm/Design/Sketch.svg",
//       },
//       {
//         name: "Stamp.svg",
//         path: "/media/icons/stockholm/Design/Stamp.svg",
//       },
//       {
//         name: "Substract.svg",
//         path: "/media/icons/stockholm/Design/Substract.svg",
//       },
//       {
//         name: "Target.svg",
//         path: "/media/icons/stockholm/Design/Target.svg",
//       },
//       {
//         name: "Union.svg",
//         path: "/media/icons/stockholm/Design/Union.svg",
//       },
//       {
//         name: "Verified.svg",
//         path: "/media/icons/stockholm/Design/Verified.svg",
//       },
//       {
//         name: "Vertical.svg",
//         path: "/media/icons/stockholm/Design/Vertical.svg",
//       },
//       {
//         name: "ZoomMinus.svg",
//         path: "/media/icons/stockholm/Design/ZoomMinus.svg",
//       },
//     ],
//   },
//   {
//     name: "Devices",
//     items: [
//       {
//         name: "Airpods.svg",
//         path: "/media/icons/stockholm/Devices/Airpods.svg",
//       },
//       {
//         name: "Android.svg",
//         path: "/media/icons/stockholm/Devices/Android.svg",
//       },
//       {
//         name: "Apple-Watch.svg",
//         path: "/media/icons/stockholm/Devices/Apple-Watch.svg",
//       },
//       {
//         name: "Battery-charging.svg",
//         path: "/media/icons/stockholm/Devices/Battery-charging.svg",
//       },
//       {
//         name: "Battery-empty.svg",
//         path: "/media/icons/stockholm/Devices/Battery-empty.svg",
//       },
//       {
//         name: "Battery-full.svg",
//         path: "/media/icons/stockholm/Devices/Battery-full.svg",
//       },
//       {
//         name: "Battery-half.svg",
//         path: "/media/icons/stockholm/Devices/Battery-half.svg",
//       },
//       {
//         name: "Bluetooth.svg",
//         path: "/media/icons/stockholm/Devices/Bluetooth.svg",
//       },
//       {
//         name: "Camera.svg",
//         path: "/media/icons/stockholm/Devices/Camera.svg",
//       },
//       {
//         name: "Cardboard-vr.svg",
//         path: "/media/icons/stockholm/Devices/Cardboard-vr.svg",
//       },
//       {
//         name: "Cassete.svg",
//         path: "/media/icons/stockholm/Devices/Cassete.svg",
//       },
//       {
//         name: "CPU1.svg",
//         path: "/media/icons/stockholm/Devices/CPU1.svg",
//       },
//       {
//         name: "CPU2.svg",
//         path: "/media/icons/stockholm/Devices/CPU2.svg",
//       },
//       {
//         name: "Diagnostics.svg",
//         path: "/media/icons/stockholm/Devices/Diagnostics.svg",
//       },
//       {
//         name: "Display1.svg",
//         path: "/media/icons/stockholm/Devices/Display1.svg",
//       },
//       {
//         name: "Display2.svg",
//         path: "/media/icons/stockholm/Devices/Display2.svg",
//       },
//       {
//         name: "Display3.svg",
//         path: "/media/icons/stockholm/Devices/Display3.svg",
//       },
//       {
//         name: "Gameboy.svg",
//         path: "/media/icons/stockholm/Devices/Gameboy.svg",
//       },
//       {
//         name: "Gamepad1.svg",
//         path: "/media/icons/stockholm/Devices/Gamepad1.svg",
//       },
//       {
//         name: "Gamepad2.svg",
//         path: "/media/icons/stockholm/Devices/Gamepad2.svg",
//       },
//       {
//         name: "Generator.svg",
//         path: "/media/icons/stockholm/Devices/Generator.svg",
//       },
//       {
//         name: "Hard-drive.svg",
//         path: "/media/icons/stockholm/Devices/Hard-drive.svg",
//       },
//       {
//         name: "Headphones.svg",
//         path: "/media/icons/stockholm/Devices/Headphones.svg",
//       },
//       {
//         name: "Homepod.svg",
//         path: "/media/icons/stockholm/Devices/Homepod.svg",
//       },
//       {
//         name: "iMac.svg",
//         path: "/media/icons/stockholm/Devices/iMac.svg",
//       },
//       {
//         name: "iPhone-back.svg",
//         path: "/media/icons/stockholm/Devices/iPhone-back.svg",
//       },
//       {
//         name: "iPhone-x-back.svg",
//         path: "/media/icons/stockholm/Devices/iPhone-x-back.svg",
//       },
//       {
//         name: "iPhone-X.svg",
//         path: "/media/icons/stockholm/Devices/iPhone-X.svg",
//       },
//       {
//         name: "Keyboard.svg",
//         path: "/media/icons/stockholm/Devices/Keyboard.svg",
//       },
//       {
//         name: "Laptop-macbook.svg",
//         path: "/media/icons/stockholm/Devices/Laptop-macbook.svg",
//       },
//       {
//         name: "Laptop.svg",
//         path: "/media/icons/stockholm/Devices/Laptop.svg",
//       },
//       {
//         name: "LTE1.svg",
//         path: "/media/icons/stockholm/Devices/LTE1.svg",
//       },
//       {
//         name: "LTE2.svg",
//         path: "/media/icons/stockholm/Devices/LTE2.svg",
//       },
//       {
//         name: "Mic.svg",
//         path: "/media/icons/stockholm/Devices/Mic.svg",
//       },
//       {
//         name: "Midi.svg",
//         path: "/media/icons/stockholm/Devices/Midi.svg",
//       },
//       {
//         name: "Mouse.svg",
//         path: "/media/icons/stockholm/Devices/Mouse.svg",
//       },
//       {
//         name: "Phone.svg",
//         path: "/media/icons/stockholm/Devices/Phone.svg",
//       },
//       {
//         name: "Printer.svg",
//         path: "/media/icons/stockholm/Devices/Printer.svg",
//       },
//       {
//         name: "Radio.svg",
//         path: "/media/icons/stockholm/Devices/Radio.svg",
//       },
//       {
//         name: "Router1.svg",
//         path: "/media/icons/stockholm/Devices/Router1.svg",
//       },
//       {
//         name: "Router2.svg",
//         path: "/media/icons/stockholm/Devices/Router2.svg",
//       },
//       {
//         name: "SD-card.svg",
//         path: "/media/icons/stockholm/Devices/SD-card.svg",
//       },
//       {
//         name: "Server.svg",
//         path: "/media/icons/stockholm/Devices/Server.svg",
//       },
//       {
//         name: "Speaker.svg",
//         path: "/media/icons/stockholm/Devices/Speaker.svg",
//       },
//       {
//         name: "Tablet.svg",
//         path: "/media/icons/stockholm/Devices/Tablet.svg",
//       },
//       {
//         name: "TV1.svg",
//         path: "/media/icons/stockholm/Devices/TV1.svg",
//       },
//       {
//         name: "TV2.svg",
//         path: "/media/icons/stockholm/Devices/SD-card.svg",
//       },
//       {
//         name: "Usb-storage.svg",
//         path: "/media/icons/stockholm/Devices/Usb-storage.svg",
//       },
//       {
//         name: "USB.svg",
//         path: "/media/icons/stockholm/Devices/USB.svg",
//       },
//       {
//         name: "Video-camera.svg",
//         path: "/media/icons/stockholm/Devices/Video-camera.svg",
//       },
//       {
//         name: "Watch1.svg",
//         path: "/media/icons/stockholm/Devices/Watch1.svg",
//       },
//       {
//         name: "Watch2.svg",
//         path: "/media/icons/stockholm/Devices/Watch2.svg",
//       },
//       {
//         name: "Wi-fi.svg",
//         path: "/media/icons/stockholm/Devices/Wi-fi.svg",
//       },
//     ],
//   },
//   {
//     name: "Electric",
//     items: [
//       {
//         name: "Air-conditioning.svg",
//         path: "/media/icons/stockholm/Electric/Air-conditioning.svg",
//       },
//       {
//         name: "air-dryer.svg",
//         path: "/media/icons/stockholm/Electric/ait-dryer.svg",
//       },
//       {
//         name: "Blender.svg",
//         path: "/media/icons/stockholm/Electric/Blender.svg",
//       },
//       {
//         name: "Fan.svg",
//         path: "/media/icons/stockholm/Electric/Fan.svg",
//       },
//       {
//         name: "Fridge.svg",
//         path: "/media/icons/stockholm/Electric/Fridge.svg",
//       },
//       {
//         name: "Gas-stove.svg",
//         path: "/media/icons/stockholm/Electric/Gas-stove.svg",
//       },
//       {
//         name: "Highvoltage.svg",
//         path: "/media/icons/stockholm/Electric/Highvoltage.svg",
//       },
//       {
//         name: "Iron.svg",
//         path: "/media/icons/stockholm/Electric/Iron.svg",
//       },
//       {
//         name: "Kettle.svg",
//         path: "/media/icons/stockholm/Electric/Kettle.svg",
//       },
//       {
//         name: "Mixer.svg",
//         path: "/media/icons/stockholm/Electric/Mixer.svg",
//       },
//       {
//         name: "Outlet.svg",
//         path: "/media/icons/stockholm/Electric/Outlet.svg",
//       },
//       {
//         name: "Range-hood.svg",
//         path: "/media/icons/stockholm/Electric/Range-hood.svg",
//       },
//       {
//         name: "Shutdown.svg",
//         path: "/media/icons/stockholm/Electric/Shutdown.svg",
//       },
//       {
//         name: "Socket-eu.svg",
//         path: "/media/icons/stockholm/Electric/Socket-eu.svg",
//       },
//       {
//         name: "Socket-us.svg",
//         path: "/media/icons/stockholm/Electric/Socket-us.svg",
//       },
//       {
//         name: "Washer.svg",
//         path: "/media/icons/stockholm/Electric/Washer.svg",
//       },
//     ],
//   },
//   {
//     name: "Files",
//     items: [
//       {
//         name: "Cloud-download.svg",
//         path: "/media/icons/stockholm/Files/Cloud-download.svg",
//       },
//       {
//         name: "Cloud-upload.svg",
//         path: "/media/icons/stockholm/Files/Cloud-upload.svg",
//       },
//       {
//         name: "Compilation.svg",
//         path: "/media/icons/stockholm/Files/Compilation.svg",
//       },
//       {
//         name: "Compiled-file.svg",
//         path: "/media/icons/stockholm/Files/Compiled-file.svg",
//       },
//       {
//         name: "Deleted-file.svg",
//         path: "/media/icons/stockholm/Files/Deleted-file.svg",
//       },
//       {
//         name: "Deleted-folder.svg",
//         path: "/media/icons/stockholm/Files/Deleted-folder.svg",
//       },
//       {
//         name: "Download.svg",
//         path: "/media/icons/stockholm/Files/Download.svg",
//       },
//       {
//         name: "DownloadedFile.svg",
//         path: "/media/icons/stockholm/Files/DownloadedFile.svg",
//       },
//       {
//         name: "DownloadsFile.svg",
//         path: "/media/icons/stockholm/Files/DownloadsFile.svg",
//       },
//       {
//         name: "Export.svg",
//         path: "/media/icons/stockholm/Files/Export.svg",
//       },
//       {
//         name: "File-cloud.svg",
//         path: "/media/icons/stockholm/Files/File-cloud.svg",
//       },
//       {
//         name: "File-done.svg",
//         path: "/media/icons/stockholm/Files/File-done.svg",
//       },
//       {
//         name: "File-minus.svg",
//         path: "/media/icons/stockholm/Files/File-minus.svg",
//       },
//       {
//         name: "File-plus.svg",
//         path: "/media/icons/stockholm/Files/File-plus.svg",
//       },
//       {
//         name: "File.svg",
//         path: "/media/icons/stockholm/Files/Socket-us.svg",
//       },
//       {
//         name: "Folder-check.svg",
//         path: "/media/icons/stockholm/Files/Folder-check.svg",
//       },
//       {
//         name: "Folder-cloud.svg",
//         path: "/media/icons/stockholm/Files/Folder-cloud.svg",
//       },
//       {
//         name: "Folder-error.svg",
//         path: "/media/icons/stockholm/Files/Folder-error.svg",
//       },
//       {
//         name: "Folder-heart.svg",
//         path: "/media/icons/stockholm/Files/Folder-heart.svg",
//       },
//       {
//         name: "Folder-minus.svg",
//         path: "/media/icons/stockholm/Files/Folder-minus.svg",
//       },
//       {
//         name: "Folder-plus.svg",
//         path: "/media/icons/stockholm/Files/Folder-plus.svg",
//       },
//       {
//         name: "Folder-solid.svg",
//         path: "/media/icons/stockholm/Files/Folder-solid.svg",
//       },
//       {
//         name: "Folder-star.svg",
//         path: "/media/icons/stockholm/Files/Folder-star.svg",
//       },
//       {
//         name: "Folder-thunder.svg",
//         path: "/media/icons/stockholm/Files/Folder-thunder.svg",
//       },
//       {
//         name: "Folder.svg",
//         path: "/media/icons/stockholm/Files/Folder.svg",
//       },
//       {
//         name: "Group-folders.svg",
//         path: "/media/icons/stockholm/Files/Group-folders.svg",
//       },
//       {
//         name: "Import.svg",
//         path: "/media/icons/stockholm/Files/Import.svg",
//       },
//       {
//         name: "Locked-folder.svg",
//         path: "/media/icons/stockholm/Files/Locked-folder.svg",
//       },
//       {
//         name: "Media-folder.svg",
//         path: "/media/icons/stockholm/Files/Media-folder.svg",
//       },
//       {
//         name: "Media.svg",
//         path: "/media/icons/stockholm/Files/Media.svg",
//       },
//       {
//         name: "Music.svg",
//         path: "/media/icons/stockholm/Files/Music.svg",
//       },
//       {
//         name: "Pictures1.svg",
//         path: "/media/icons/stockholm/Files/Pictures1.svg",
//       },
//       {
//         name: "Pictures2.svg",
//         path: "/media/icons/stockholm/Files/Pictures2.svg",
//       },
//       {
//         name: "Protected-file.svg",
//         path: "/media/icons/stockholm/Files/Protected-file.svg",
//       },
//       {
//         name: "Selected-file.svg",
//         path: "/media/icons/stockholm/Files/Selected-file.svg",
//       },
//       {
//         name: "Share.svg",
//         path: "/media/icons/stockholm/Files/Share.svg",
//       },
//       {
//         name: "Upload-folder.svg",
//         path: "/media/icons/stockholm/Files/Upload-folder.svg",
//       },
//       {
//         name: "Upload.svg",
//         path: "/media/icons/stockholm/Files/Upload.svg",
//       },
//       {
//         name: "Uploaded-file.svg",
//         path: "/media/icons/stockholm/Files/Uploaded-file.svg",
//       },
//       {
//         name: "User-folder.svg",
//         path: "/media/icons/stockholm/Files/User-folder.svg",
//       },
//     ],
//   },
//   {
//     name: "Food",
//     items: [
//       {
//         name: "Beer.svg",
//         path: "/media/icons/stockholm/Food/Beer.svg",
//       },
//       {
//         name: "Bottle1.svg",
//         path: "/media/icons/stockholm/Food/Bottle1.svg",
//       },
//       {
//         name: "Bottle2.svg",
//         path: "/media/icons/stockholm/Food/Bottle2.svg",
//       },
//       {
//         name: "Bread.svg",
//         path: "/media/icons/stockholm/Food/Bread.svg",
//       },
//       {
//         name: "Bucket.svg",
//         path: "/media/icons/stockholm/Food/Bucket.svg",
//       },
//       {
//         name: "Burger.svg",
//         path: "/media/icons/stockholm/Food/Burger.svg",
//       },
//       {
//         name: "Cake.svg",
//         path: "/media/icons/stockholm/Food/Cake.svg",
//       },
//       {
//         name: "Carrot.svg",
//         path: "/media/icons/stockholm/Food/Carrot.svg",
//       },
//       {
//         name: "Cheese.svg",
//         path: "/media/icons/stockholm/Food/Cheese.svg",
//       },
//       {
//         name: "Chicken.svg",
//         path: "/media/icons/stockholm/Food/Chicken.svg",
//       },
//       // {
//       //   name: "Coffe1.svg",
//       //   path: "/media/icons/stockholm/Food/Coffe1.svg",
//       // },
//       // {
//       //   name: "Coffe2.svg",
//       //   path: "/media/icons/stockholm/Food/Coffe2.svg",
//       // },
//       {
//         name: "Cookie.svg",
//         path: "/media/icons/stockholm/Food/Cookie.svg",
//       },
//       {
//         name: "Dinner.svg",
//         path: "/media/icons/stockholm/Food/Dinner.svg",
//       },
//       {
//         name: "Fish.svg",
//         path: "/media/icons/stockholm/Food/Fish.svg",
//       },
//       {
//         name: "French Bread.svg",
//         path: "/media/icons/stockholm/Food/French Bread.svg",
//       },
//       {
//         name: "Glass-martini.svg",
//         path: "/media/icons/stockholm/Food/Glass-martini.svg",
//       },
//       {
//         name: "Ice-cream1.svg",
//         path: "/media/icons/stockholm/Food/Ice-cream1.svg",
//       },
//       {
//         name: "Ice-cream2.svg",
//         path: "/media/icons/stockholm/Food/Ice-cream2.svg",
//       },
//       {
//         name: "Miso-soup.svg",
//         path: "/media/icons/stockholm/Food/Miso-soup.svg",
//       },
//       {
//         name: "Orange.svg",
//         path: "/media/icons/stockholm/Food/Orange.svg",
//       },
//       {
//         name: "Pizza.svg",
//         path: "/media/icons/stockholm/Food/Pizza.svg",
//       },
//       {
//         name: "Sushi.svg",
//         path: "/media/icons/stockholm/Food/Sushi.svg",
//       },
//       {
//         name: "Two-bottles.svg",
//         path: "/media/icons/stockholm/Food/Two-bottles.svg",
//       },
//       {
//         name: "Wine.svg",
//         path: "/media/icons/stockholm/Food/Wine.svg",
//       },
//     ],
//   },
//   {
//     name: "Home",
//     items: [
//       {
//         name: "Air-ballon.svg",
//         path: "/media/icons/stockholm/Home/Air-ballon.svg",
//       },
//       {
//         name: "Alarm-clock.svg",
//         path: "/media/icons/stockholm/Home/Alarm-clock.svg",
//       },
//       {
//         name: "Armchair.svg",
//         path: "/media/icons/stockholm/Home/Armchair.svg",
//       },
//       {
//         name: "Bag-chair.svg",
//         path: "/media/icons/stockholm/Home/Bag-chair.svg",
//       },
//       {
//         name: "Bath.svg",
//         path: "/media/icons/stockholm/Home/Bath.svg",
//       },
//       {
//         name: "Bed.svg",
//         path: "/media/icons/stockholm/Home/Bed.svg",
//       },
//       {
//         name: "Book-open.svg",
//         path: "/media/icons/stockholm/Home/Book-open.svg",
//       },
//       {
//         name: "Box.svg",
//         path: "/media/icons/stockholm/Home/Box.svg",
//       },
//       {
//         name: "Broom.svg",
//         path: "/media/icons/stockholm/Home/Broom.svg",
//       },
//       {
//         name: "Building.svg",
//         path: "/media/icons/stockholm/Home/Building.svg",
//       },
//       {
//         name: "Bulb1.svg",
//         path: "/media/icons/stockholm/Home/Bulb1.svg",
//       },
//       {
//         name: "Bulb2.svg",
//         path: "/media/icons/stockholm/Home/Bulb2.svg",
//       },
//       {
//         name: "Air-ballon.svg",
//         path: "/media/icons/stockholm/Home/Air-ballon.svg",
//       },
//       {
//         name: "Chair1.svg",
//         path: "/media/icons/stockholm/Home/Chair1.svg",
//       },
//       {
//         name: "Chair2.svg",
//         path: "/media/icons/stockholm/Home/Chair2.svg",
//       },
//       {
//         name: "Clock.svg",
//         path: "/media/icons/stockholm/Home/Clock.svg",
//       },
//       {
//         name: "Commode1.svg",
//         path: "/media/icons/stockholm/Home/Commode1.svg",
//       },
//       {
//         name: "Commode2.svg",
//         path: "/media/icons/stockholm/Home/Commode2.svg",
//       },
//       {
//         name: "Couch.svg",
//         path: "/media/icons/stockholm/Home/Couch.svg",
//       },
//       {
//         name: "Cupboard.svg",
//         path: "/media/icons/stockholm/Home/Cupboard.svg",
//       },
//       {
//         name: "Curtains.svg",
//         path: "/media/icons/stockholm/Home/Curtains.svg",
//       },
//       {
//         name: "Deer.svg",
//         path: "/media/icons/stockholm/Home/Deer.svg",
//       },
//       {
//         name: "Door-open.svg",
//         path: "/media/icons/stockholm/Home/Door-open.svg",
//       },
//       {
//         name: "Earth.svg",
//         path: "/media/icons/stockholm/Home/Earth.svg",
//       },
//       {
//         name: "Fireplace.svg",
//         path: "/media/icons/stockholm/Home/Fireplace.svg",
//       },
//       {
//         name: "Flashlight.svg",
//         path: "/media/icons/stockholm/Home/Flashlight.svg",
//       },
//       {
//         name: "Flower1.svg",
//         path: "/media/icons/stockholm/Home/Flower1.svg",
//       },
//       {
//         name: "Flower2.svg",
//         path: "/media/icons/stockholm/Home/Flower2.svg",
//       },
//       {
//         name: "Flower3.svg",
//         path: "/media/icons/stockholm/Home/Flower3.svg",
//       },
//       {
//         name: "Globe.svg",
//         path: "/media/icons/stockholm/Home/Globe.svg",
//       },
//       {
//         name: "Home-heart.svg",
//         path: "/media/icons/stockholm/Home/Home-heart.svg",
//       },
//       {
//         name: "Home.svg",
//         path: "/media/icons/stockholm/Home/Home.svg",
//       },
//       {
//         name: "Key.svg",
//         path: "/media/icons/stockholm/Home/Key.svg",
//       },
//       {
//         name: "Ladder.svg",
//         path: "/media/icons/stockholm/Home/Ladder.svg",
//       },
//       {
//         name: "Lamp1.svg",
//         path: "/media/icons/stockholm/Home/Lamp1.svg",
//       },
//       {
//         name: "Lamp2.svg",
//         path: "/media/icons/stockholm/Home/Lamp2.svg",
//       },
//       {
//         name: "Library.svg",
//         path: "/media/icons/stockholm/Home/Library.svg",
//       },
//       {
//         name: "Mailbox.svg",
//         path: "/media/icons/stockholm/Home/Mailbox.svg",
//       },
//       {
//         name: "Mirror.svg",
//         path: "/media/icons/stockholm/Home/Mirror.svg",
//       },
//       {
//         name: "Picture.svg",
//         path: "/media/icons/stockholm/Home/Picture.svg",
//       },
//       {
//         name: "Ruller.svg",
//         path: "/media/icons/stockholm/Home/Ruller.svg",
//       },
//       {
//         name: "Stairs.svg",
//         path: "/media/icons/stockholm/Home/Stairs.svg",
//       },
//       {
//         name: "Timer.svg",
//         path: "/media/icons/stockholm/Home/Timer.svg",
//       },
//       {
//         name: "Toilet.svg",
//         path: "/media/icons/stockholm/Home/Toilet.svg",
//       },
//       {
//         name: "Towel.svg",
//         path: "/media/icons/stockholm/Home/Towel.svg",
//       },
//       {
//         name: "Trash.svg",
//         path: "/media/icons/stockholm/Home/Trash.svg",
//       },
//       {
//         name: "Water-mixer.svg",
//         path: "/media/icons/stockholm/Home/Water-mixer.svg",
//       },
//       {
//         name: "Weight1.svg",
//         path: "/media/icons/stockholm/Home/Weight1.svg",
//       },
//       {
//         name: "Weight2.svg",
//         path: "/media/icons/stockholm/Home/Weight2.svg",
//       },
//       {
//         name: "Wood-horse.svg",
//         path: "/media/icons/stockholm/Home/Wood-horse.svg",
//       },
//       {
//         name: "Wood1.svg",
//         path: "/media/icons/stockholm/Home/Wood1.svg",
//       },
//       {
//         name: "Wood2.svg",
//         path: "/media/icons/stockholm/Home/Wood2.svg",
//       },
//     ],
//   },
//   {
//     name: "Layout",
//     items: [
//       {
//         name: "Layout-3d.svg",
//         path: "/media/icons/stockholm/Layout/Layout-3d.svg",
//       },
//       {
//         name: "Layout-4-blocks-2.svg",
//         path: "/media/icons/stockholm/Layout/Layout-4-blocks-2.svg",
//       },
//       {
//         name: "Layout-4-blocks.svg",
//         path: "/media/icons/stockholm/Layout/Layout-4-blocks.svg",
//       },
//       {
//         name: "Layout-arrange.svg",
//         path: "/media/icons/stockholm/Layout/Layout-arrange.svg",
//       },
//       {
//         name: "Layout-grid.svg",
//         path: "/media/icons/stockholm/Layout/Layout-grid.svg",
//       },
//       {
//         name: "Layout-horizontal.svg",
//         path: "/media/icons/stockholm/Layout/Layout-horizontal.svg",
//       },
//       {
//         name: "Layout-left-panel-1.svg",
//         path: "/media/icons/stockholm/Layout/Layout-panel-1.svg",
//       },
//       {
//         name: "Layout-left-panel-2.svg",
//         path: "/media/icons/stockholm/Layout/Layout-left-panel-2.svg",
//       },
//       {
//         name: "Layout-polygon.svg",
//         path: "/media/icons/stockholm/Layout/Layout-polygon.svg",
//       },
//       {
//         name: "Layout-right-panel-1.svg",
//         path: "/media/icons/stockholm/Layout/Layout-right-panel-1.svg",
//       },
//       {
//         name: "Layout-right-panel-2.svg",
//         path: "/media/icons/stockholm/Layout/Layout-right-panel-2.svg",
//       },
//       {
//         name: "Layout-top-panel-1.svg",
//         path: "/media/icons/stockholm/Layout/Layout-top-panel-1.svg",
//       },
//       {
//         name: "Layout-top-panel-2.svg",
//         path: "/media/icons/stockholm/Layout/Layout-top-panel-2.svg",
//       },
//       {
//         name: "Layout-top-panel-3.svg",
//         path: "/media/icons/stockholm/Layout/Layout-top-panel-3.svg",
//       },
//       {
//         name: "Layout-top-panel-4.svg",
//         path: "/media/icons/stockholm/Layout/Layout-top-panel-4.svg",
//       },
//       {
//         name: "Layout-top-panel-5.svg",
//         path: "/media/icons/stockholm/Layout/Layout-top-panel-5.svg",
//       },
//       {
//         name: "Layout-top-panel-6.svg",
//         path: "/media/icons/stockholm/Layout/Layout-top-panel-6.svg",
//       },
//       {
//         name: "Layout-vertical.svg",
//         path: "/media/icons/stockholm/Layout/Layout-vertical.svg",
//       },
//     ],
//   },
//   {
//     name: "Map",
//     items: [
//       {
//         name: "Compass.svg",
//         path: "/media/icons/stockholm/Map/Compass.svg",
//       },
//       {
//         name: "Direction1.svg",
//         path: "/media/icons/stockholm/Map/Direction1.svg",
//       },
//       {
//         name: "Direction2.svg",
//         path: "/media/icons/stockholm/Map/Direction2.svg",
//       },
//       {
//         name: "Location-arrow.svg",
//         path: "/media/icons/stockholm/Map/Location-arrow.svg",
//       },
//       {
//         name: "Marker1.svg",
//         path: "/media/icons/stockholm/Map/Marker1.svg",
//       },
//       {
//         name: "Marker2.svg",
//         path: "/media/icons/stockholm/Map/Marker2.svg",
//       },
//       {
//         name: "Position.svg",
//         path: "/media/icons/stockholm/Map/Position.svg",
//       },
//     ],
//   },
//   {
//     name: "Media",
//     items: [
//       {
//         name: "Add-music.svg",
//         path: "/media/icons/stockholm/Media/Add-music.svg",
//       },
//       {
//         name: "Airplay-video.svg",
//         path: "/media/icons/stockholm/Media/Airplay-video.svg",
//       },
//       {
//         name: "Airplay.svg",
//         path: "/media/icons/stockholm/Media/Airplay.svg",
//       },
//       {
//         name: "Back.svg",
//         path: "/media/icons/stockholm/Media/Back.svg",
//       },
//       {
//         name: "Backward.svg",
//         path: "/media/icons/stockholm/Media/Backward.svg",
//       },
//       {
//         name: "CD.svg",
//         path: "/media/icons/stockholm/Media/CD.svg",
//       },
//       {
//         name: "DVD.svg",
//         path: "/media/icons/stockholm/Media/DVD.svg",
//       },
//       {
//         name: "Eject.svg",
//         path: "/media/icons/stockholm/Media/Eject.svg",
//       },
//       {
//         name: "Equalizer.svg",
//         path: "/media/icons/stockholm/Media/Equalizer.svg",
//       },
//       {
//         name: "Forward.svg",
//         path: "/media/icons/stockholm/Media/Forward.svg",
//       },
//       {
//         name: "Media-library1.svg",
//         path: "/media/icons/stockholm/Media/Media-library1.svg",
//       },
//       {
//         name: "Media-library2.svg",
//         path: "/media/icons/stockholm/Media/Media-library2.svg",
//       },
//       {
//         name: "Media-library3.svg",
//         path: "/media/icons/stockholm/Media/Media-library3.svg",
//       },
//       {
//         name: "Movie-lane1.svg",
//         path: "/media/icons/stockholm/Media/Movie-lane1.svg",
//       },
//       {
//         name: "Movie-Lane2.svg",
//         path: "/media/icons/stockholm/Media/Movie-Lane2.svg",
//       },
//       {
//         name: "Music-cloud.svg",
//         path: "/media/icons/stockholm/Media/Music-cloud.svg",
//       },
//       {
//         name: "Music-note.svg",
//         path: "/media/icons/stockholm/Media/Music-note.svg",
//       },
//       {
//         name: "Mute.svg",
//         path: "/media/icons/stockholm/Media/Mute.svg",
//       },
//       {
//         name: "Next.svg",
//         path: "/media/icons/stockholm/Media/Next.svg",
//       },
//       {
//         name: "Pause.svg",
//         path: "/media/icons/stockholm/Media/Pause.svg",
//       },
//       {
//         name: "Play.svg",
//         path: "/media/icons/stockholm/Media/Play.svg",
//       },
//       {
//         name: "Playlist1.svg",
//         path: "/media/icons/stockholm/Media/Playlist1.svg",
//       },
//       {
//         name: "Playlist2.svg",
//         path: "/media/icons/stockholm/Media/Playlist2.svg",
//       },
//       {
//         name: "Rec.svg",
//         path: "/media/icons/stockholm/Media/Rec.svg",
//       },
//       {
//         name: "Repeat-one.svg",
//         path: "/media/icons/stockholm/Media/Repeat-one.svg",
//       },
//       {
//         name: "Repeat.svg",
//         path: "/media/icons/stockholm/Media/Repeat.svg",
//       },
//       {
//         name: "Shuffle.svg",
//         path: "/media/icons/stockholm/Media/Shuffle.svg",
//       },
//       {
//         name: "Volume-down.svg",
//         path: "/media/icons/stockholm/Media/Volume-down.svg",
//       },
//       {
//         name: "Volume-full.svg",
//         path: "/media/icons/stockholm/Media/Volume-full.svg",
//       },
//       {
//         name: "Volume-half.svg",
//         path: "/media/icons/stockholm/Media/Volume-half.svg",
//       },
//       {
//         name: "Volume-up.svg",
//         path: "/media/icons/stockholm/Media/Value-up.svg",
//       },
//       {
//         name: "Vynil.svg",
//         path: "/media/icons/stockholm/Media/Vynil.svg",
//       },
//       {
//         name: "Youtube.svg",
//         path: "/media/icons/stockholm/Media/Youtube.svg",
//       },
//     ],
//   },
//   {
//     name: "Navigation",
//     items: [
//       {
//         name: "Angle-double-down.svg",
//         path: "/media/icons/stockholm/Navigation/Angle-double-down.svg",
//       },
//       {
//         name: "Angle-double-left.svg",
//         path: "/media/icons/stockholm/Navigation/Angle-double-left.svg",
//       },
//       {
//         name: "Angle-double-right.svg",
//         path: "/media/icons/stockholm/Navigation/Angle-double-right.svg",
//       },
//       {
//         name: "Angle-double-up.svg",
//         path: "/media/icons/stockholm/Navigation/Angle-double-up.svg",
//       },
//       {
//         name: "Angle-down.svg",
//         path: "/media/icons/stockholm/Navigation/Angle-down.svg",
//       },
//       {
//         name: "Angle-left.svg",
//         path: "/media/icons/stockholm/Navigation/Angle-left.svg",
//       },
//       {
//         name: "Angle-right.svg",
//         path: "/media/icons/stockholm/Navigation/Angle-right.svg",
//       },
//       {
//         name: "Arrow-down.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-down.svg",
//       },
//       {
//         name: "Arrow-from-bottom.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-from-bottom.svg",
//       },
//       {
//         name: "Arrow-from-bottom.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-from-bottom.svg",
//       },
//       {
//         name: "Arrow-from-left.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-from-left.svg",
//       },
//       {
//         name: "Arrow-from-right.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-from-right.svg",
//       },
//       {
//         name: "Arrow-from-top.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-from-top.svg",
//       },
//       {
//         name: "Arrow-left.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-left.svg",
//       },
//       {
//         name: "Arrow-right.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-right.svg",
//       },
//       {
//         name: "Arrow-to-bottom.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-to-bottom.svg",
//       },
//       {
//         name: "Arrow-to-left.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-to-left.svg",
//       },
//       {
//         name: "Arrow-to-right.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-to-right.svg",
//       },
//       {
//         name: "Arrow-to-up.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-to-up.svg",
//       },
//       {
//         name: "Arrow-up.svg",
//         path: "/media/icons/stockholm/Navigation/Arrow-up.svg",
//       },
//       {
//         name: "Arrows-h.svg",
//         path: "/media/icons/stockholm/Navigation/Arrows-h.svg",
//       },
//       {
//         name: "Arrows-v.svg",
//         path: "/media/icons/stockholm/Navigation/Arrows-v.svg",
//       },
//       {
//         name: "Check.svg",
//         path: "/media/icons/stockholm/Navigation/Check.svg",
//       },
//       {
//         name: "Close.svg",
//         path: "/media/icons/stockholm/Navigation/Close.svg",
//       },
//       {
//         name: "Double-check.svg",
//         path: "/media/icons/stockholm/Navigation/Double-check.svg",
//       },
//       {
//         name: "Down-2.svg",
//         path: "/media/icons/stockholm/Navigation/Down-2.svg",
//       },
//       {
//         name: "Down-left.svg",
//         path: "/media/icons/stockholm/Navigation/Down-left.svg",
//       },
//       {
//         name: "Down-right.svg",
//         path: "/media/icons/stockholm/Navigation/Down-right.svg",
//       },
//       {
//         name: "Exchange.svg",
//         path: "/media/icons/stockholm/Navigation/Exchange.svg",
//       },
//       {
//         name: "Left 3.svg",
//         path: "/media/icons/stockholm/Navigation/Left 3.svg",
//       },
//       {
//         name: "Left-2.svg",
//         path: "/media/icons/stockholm/Navigation/Left-2.svg",
//       },
//       {
//         name: "Minus.svg",
//         path: "/media/icons/stockholm/Navigation/Minus.svg",
//       },
//       {
//         name: "Plus.svg",
//         path: "/media/icons/stockholm/Navigation/Plus.svg",
//       },
//       {
//         name: "Right 3.svg",
//         path: "/media/icons/stockholm/Navigation/Right 3.svg",
//       },
//       {
//         name: "Right-2.svg",
//         path: "/media/icons/stockholm/Navigation/Right-2.svg",
//       },
//       {
//         name: "Route.svg",
//         path: "/media/icons/stockholm/Navigation/Route.svg",
//       },
//       {
//         name: "Sign-in.svg",
//         path: "/media/icons/stockholm/Navigation/Sign-in.svg",
//       },
//       {
//         name: "Sign-out.svg",
//         path: "/media/icons/stockholm/Navigation/Sign-out.svg",
//       },
//       {
//         name: "Up-2.svg",
//         path: "/media/icons/stockholm/Navigation/Up-2.svg",
//       },
//       {
//         name: "Up-down.svg",
//         path: "/media/icons/stockholm/Navigation/Up-down.svg",
//       },
//       {
//         name: "Up-left.svg",
//         path: "/media/icons/stockholm/Navigation/Up-left.svg",
//       },
//       {
//         name: "Up-right.svg",
//         path: "/media/icons/stockholm/Navigation/Up-right.svg",
//       },
//       {
//         name: "Waiting.svg",
//         path: "/media/icons/stockholm/Navigation/Waiting.svg",
//       },
//     ],
//   },
//   {
//     name: "Shopping",
//     items: [
//       {
//         name: "ATM.svg",
//         path: "/media/icons/stockholm/Shopping/ATM.svg",
//       },
//       {
//         name: "Bag1.svg",
//         path: "/media/icons/stockholm/Shopping/Bag1.svg",
//       },
//       {
//         name: "Bag2.svg",
//         path: "/media/icons/stockholm/Shopping/Bag2.svg",
//       },
//       {
//         name: "Barcode-read.svg",
//         path: "/media/icons/stockholm/Shopping/Barcode-read.svg",
//       },
//       {
//         name: "Barcode-scan.svg",
//         path: "/media/icons/stockholm/Shopping/Barcode-scan.svg",
//       },
//       {
//         name: "ATM.svg",
//         path: "/media/icons/stockholm/Shopping/ATM.svg",
//       },
//       {
//         name: "Barcode.svg",
//         path: "/media/icons/stockholm/Shopping/Barcode.svg",
//       },
//       {
//         name: "Bitcoin.svg",
//         path: "/media/icons/stockholm/Shopping/Bitcoin.svg",
//       },
//       {
//         name: "Box1.svg",
//         path: "/media/icons/stockholm/Shopping/Box1.svg",
//       },
//       {
//         name: "Box2.svg",
//         path: "/media/icons/stockholm/Shopping/Box2.svg",
//       },
//       {
//         name: "Box3.svg",
//         path: "/media/icons/stockholm/Shopping/Box3.svg",
//       },
//       {
//         name: "Calculator.svg",
//         path: "/media/icons/stockholm/Shopping/Calculator.svg",
//       },
//       {
//         name: "Cart1.svg",
//         path: "/media/icons/stockholm/Shopping/Cart1.svg",
//       },
//       {
//         name: "Cart2.svg",
//         path: "/media/icons/stockholm/Shopping/Cart2.svg",
//       },
//       {
//         name: "Cart3.svg",
//         path: "/media/icons/stockholm/Shopping/Cart3.svg",
//       },
//       {
//         name: "Cart4.svg",
//         path: "/media/icons/stockholm/Shopping/Cart4.svg",
//       },
//       {
//         name: "Cart5.svg",
//         path: "/media/icons/stockholm/Shopping/Cart5.svg",
//       },
//       {
//         name: "Chart-bar1.svg",
//         path: "/media/icons/stockholm/Shopping/Chart-bar1.svg",
//       },
//       {
//         name: "Chart-bar1.svg",
//         path: "/media/icons/stockholm/Shopping/Chart-bar1.svg",
//       },
//       {
//         name: "Chart-bar2.svg",
//         path: "/media/icons/stockholm/Shopping/Chart-bar2.svg",
//       },
//       {
//         name: "Chart-bar3.svg",
//         path: "/media/icons/stockholm/Shopping/Chart-bar3.svg",
//       },
//       {
//         name: "Chart-line1.svg",
//         path: "/media/icons/stockholm/Shopping/Chart-line1.svg",
//       },
//       {
//         name: "Chart-line2.svg",
//         path: "/media/icons/stockholm/Shopping/Chart-line2.svg",
//       },
//       {
//         name: "Chart-pie.svg",
//         path: "/media/icons/stockholm/Shopping/Chart-pie.svg",
//       },
//       {
//         name: "Credit-card.svg",
//         path: "/media/icons/stockholm/Shopping/Credit-card.svg",
//       },
//       {
//         name: "Dollar.svg",
//         path: "/media/icons/stockholm/Shopping/Dollar.svg",
//       },
//       {
//         name: "Euro.svg",
//         path: "/media/icons/stockholm/Shopping/Euro.svg",
//       },
//       {
//         name: "Gift.svg",
//         path: "/media/icons/stockholm/Shopping/Gift.svg",
//       },
//       {
//         name: "Loader.svg",
//         path: "/media/icons/stockholm/Shopping/Loader.svg",
//       },
//       {
//         name: "MC.svg",
//         path: "/media/icons/stockholm/Shopping/MC.svg",
//       },
//       {
//         name: "Money.svg",
//         path: "/media/icons/stockholm/Shopping/Money.svg",
//       },
//       {
//         name: "Pound.svg",
//         path: "/media/icons/stockholm/Shopping/Pound.svg",
//       },
//       {
//         name: "Price1.svg",
//         path: "/media/icons/stockholm/Shopping/Price1.svg",
//       },
//       {
//         name: "Price2.svg",
//         path: "/media/icons/stockholm/Shopping/Price2.svg",
//       },
//       {
//         name: "Rouble.svg",
//         path: "/media/icons/stockholm/Shopping/Rouble.svg",
//       },
//       {
//         name: "Safe.svg",
//         path: "/media/icons/stockholm/Shopping/Safe.svg",
//       },
//       {
//         name: "Sale1.svg",
//         path: "/media/icons/stockholm/Shopping/Sale1.svg",
//       },
//       {
//         name: "Sale2.svg",
//         path: "/media/icons/stockholm/Shopping/Sale2.svg",
//       },
//       {
//         name: "Settings.svg",
//         path: "/media/icons/stockholm/Shopping/Settings.svg",
//       },
//       {
//         name: "Sort1.svg",
//         path: "/media/icons/stockholm/Shopping/Sort1.svg",
//       },
//       {
//         name: "Sort2.svg",
//         path: "/media/icons/stockholm/Shopping/Sort2.svg",
//       },
//       {
//         name: "Sort3.svg",
//         path: "/media/icons/stockholm/Shopping/Sort3.svg",
//       },
//       {
//         name: "Ticket.svg",
//         path: "/media/icons/stockholm/Shopping/Ticket.svg",
//       },
//       {
//         name: "Wallet.svg",
//         path: "/media/icons/stockholm/Shopping/Wallet.svg",
//       },
//       {
//         name: "Wallet2.svg",
//         path: "/media/icons/stockholm/Shopping/Wallet2.svg",
//       },
//       {
//         name: "Wallet3.svg",
//         path: "/media/icons/stockholm/Shopping/Wallet3.svg",
//       },
//     ],
//   },
//   {
//     name: "Text",
//     items: [
//       {
//         name: "Align-auto.svg",
//         path: "/media/icons/stockholm/Text/Align-auto.svg",
//       },
//       {
//         name: "Align-center.svg",
//         path: "/media/icons/stockholm/Text/Align-center.svg",
//       },
//       {
//         name: "Align-justify.svg",
//         path: "/media/icons/stockholm/Text/Align-justify.svg",
//       },
//       {
//         name: "Align-left.svg",
//         path: "/media/icons/stockholm/Text/Align-left.svg",
//       },
//       {
//         name: "Align-right.svg",
//         path: "/media/icons/stockholm/Text/Align-right.svg",
//       },
//       {
//         name: "Article.svg",
//         path: "/media/icons/stockholm/Text/Article.svg",
//       },
//       {
//         name: "Bold.svg",
//         path: "/media/icons/stockholm/Text/Bold.svg",
//       },
//       {
//         name: "Bullet-list.svg",
//         path: "/media/icons/stockholm/Text/Bullet-list.svg",
//       },
//       {
//         name: "Code.svg",
//         path: "/media/icons/stockholm/Text/Code.svg",
//       },
//       {
//         name: "Dots.svg",
//         path: "/media/icons/stockholm/Text/Dots.svg",
//       },
//       {
//         name: "Edit-text.svg",
//         path: "/media/icons/stockholm/Text/Edit-text.svg",
//       },
//       {
//         name: "Filter.svg",
//         path: "/media/icons/stockholm/Text/Filter.svg",
//       },
//       {
//         name: "Font.svg",
//         path: "/media/icons/stockholm/Text/Font.svg",
//       },
//       {
//         name: "H1.svg",
//         path: "/media/icons/stockholm/Text/H1.svg",
//       },
//       {
//         name: "H2.svg",
//         path: "/media/icons/stockholm/Text/H2.svg",
//       },
//       // {
//       //   name: "Italic.svg",
//       //   path: "/media/icons/stockholm/Text/Italic.svg",
//       // },
//       {
//         name: "Menu.svg",
//         path: "/media/icons/stockholm/Text/Menu.svg",
//       },
//       {
//         name: "Paragraph.svg",
//         path: "/media/icons/stockholm/Text/Paragraph.svg",
//       },
//       // {
//       //   name: "Pen.svg",
//       //   path: "/media/icons/stockholm/Text/Pen.svg",
//       // },
//       {
//         name: "Quote1.svg",
//         path: "/media/icons/stockholm/Text/Quote1.svg",
//       },
//       {
//         name: "Quote2.svg",
//         path: "/media/icons/stockholm/Text/Quote2.svg",
//       },
//       {
//         name: "Redo.svg",
//         path: "/media/icons/stockholm/Text/Redo.svg",
//       },
//       // {
//       //   name: "Strikethrough.svg",
//       //   path: "/media/icons/stockholm/Text/Striketrhough.svg",
//       // },
//       {
//         name: "Text-height.svg",
//         path: "/media/icons/stockholm/Text/Text-height.svg",
//       },
//       {
//         name: "Text-width.svg",
//         path: "/media/icons/stockholm/Text/Text-width.svg",
//       },
//       {
//         name: "Text.svg",
//         path: "/media/icons/stockholm/Text/Text.svg",
//       },
//       {
//         name: "Toggle-Left.svg",
//         path: "/media/icons/stockholm/Text/Toggle-Left.svg",
//       },
//       {
//         name: "Toggle-Right.svg",
//         path: "/media/icons/stockholm/Text/Toggle-Right.svg",
//       },
//       {
//         name: "Toggle.svg",
//         path: "/media/icons/stockholm/Text/Toggle.svg",
//       },
//       {
//         name: "Underline.svg",
//         path: "/media/icons/stockholm/Text/Underline.svg",
//       },
//       {
//         name: "Undo.svg",
//         path: "/media/icons/stockholm/Text/Undo.svg",
//       },
//     ],
//   },
//   {
//     name: "Tools",
//     items: [
//       {
//         name: "Angle Grinder.svg",
//         path: "/media/icons/stockholm/Tools/Angle Grinder.svg",
//       },
//       {
//         name: "Axe.svg",
//         path: "/media/icons/stockholm/Tools/Axe.svg",
//       },
//       {
//         name: "Brush.svg",
//         path: "/media/icons/stockholm/Tools/Brush.svg",
//       },
//       {
//         name: "Compass.svg",
//         path: "/media/icons/stockholm/Tools/Compass.svg",
//       },
//       {
//         name: "Hummer.svg",
//         path: "/media/icons/stockholm/Tools/Hummer.svg",
//       },
//       {
//         name: "Hummer2.svg",
//         path: "/media/icons/stockholm/Tools/Hummer2.svg",
//       },
//       {
//         name: "Pantone.svg",
//         path: "/media/icons/stockholm/Tools/Pantone.svg",
//       },
//       {
//         name: "Road-Cone.svg",
//         path: "/media/icons/stockholm/Tools/Road-Cone.svg",
//       },
//       {
//         name: "Roller.svg",
//         path: "/media/icons/stockholm/Tools/Roller.svg",
//       },
//       {
//         name: "Roulette.svg",
//         path: "/media/icons/stockholm/Tools/Roulette.svg",
//       },
//       {
//         name: "Screwdriver.svg",
//         path: "/media/icons/stockholm/Tools/Screwdriver.svg",
//       },
//       {
//         name: "Shovel.svg",
//         path: "/media/icons/stockholm/Tools/Shovel.svg",
//       },
//       {
//         name: "Spatula.svg",
//         path: "/media/icons/stockholm/Tools/Spatula.svg",
//       },
//       {
//         name: "Swiss-knife.svg",
//         path: "/media/icons/stockholm/Tools/Swiss-knife.svg",
//       },
//       {
//         name: "Tools.svg",
//         path: "/media/icons/stockholm/Tools/Tools.svg",
//       },
//     ],
//   },
//   {
//     name: "Weather",
//     items: [
//       {
//         name: "Celcium.svg",
//         path: "/media/icons/stockholm/Weather/Celcium.svg",
//       },
//       {
//         name: "Cloud-fog.svg",
//         path: "/media/icons/stockholm/Weather/Cloud-fog.svg",
//       },
//       {
//         name: "Cloud-sun.svg",
//         path: "/media/icons/stockholm/Weather/Cloud-sun.svg",
//       },
//       {
//         name: "Cloud-wind.svg",
//         path: "/media/icons/stockholm/Weather/Cloud-wind.svg",
//       },
//       {
//         name: "Cloud1.svg",
//         path: "/media/icons/stockholm/Weather/Cloud1.svg",
//       },
//       {
//         name: "Cloud2.svg",
//         path: "/media/icons/stockholm/Weather/Cloud2.svg",
//       },
//       {
//         name: "Cloudy-night.svg",
//         path: "/media/icons/stockholm/Weather/Cloudy-night.svg",
//       },
//       {
//         name: "Cloudy.svg",
//         path: "/media/icons/stockholm/Weather/Cloudy.svg",
//       },
//       {
//         name: "Day-rain.svg",
//         path: "/media/icons/stockholm/Weather/Day-rain.svg",
//       },
//       {
//         name: "Fahrenheit.svg",
//         path: "/media/icons/stockholm/Weather/Fahrenheit.svg",
//       },
//       {
//         name: "Fog.svg",
//         path: "/media/icons/stockholm/Weather/Fog.svg",
//       },
//       {
//         name: "Moon.svg",
//         path: "/media/icons/stockholm/Weather/Moon.svg",
//       },
//       {
//         name: "Night-fog.svg",
//         path: "/media/icons/stockholm/Weather/Night-fog.svg",
//       },
//       {
//         name: "Night-rain.svg",
//         path: "/media/icons/stockholm/Weather/Night-rain.svg",
//       },
//       {
//         name: "Rain1.svg",
//         path: "/media/icons/stockholm/Weather/Rain1.svg",
//       },
//       {
//         name: "Rain2.svg",
//         path: "/media/icons/stockholm/Weather/Rain2.svg",
//       },
//       {
//         name: "Rain5.svg",
//         path: "/media/icons/stockholm/Weather/Rain5.svg",
//       },
//       {
//         name: "Rainbow.svg",
//         path: "/media/icons/stockholm/Weather/Rainbow.svg",
//       },
//       {
//         name: "Snow.svg",
//         path: "/media/icons/stockholm/Weather/Snow.svg",
//       },
//       {
//         name: "Snow1.svg",
//         path: "/media/icons/stockholm/Weather/Snow1.svg",
//       },
//       {
//         name: "Snow2.svg",
//         path: "/media/icons/stockholm/Weather/Snow2.svg",
//       },
//       {
//         name: "Snow3.svg",
//         path: "/media/icons/stockholm/Weather/Snow3.svg",
//       },
//       {
//         name: "Storm.svg",
//         path: "/media/icons/stockholm/Weather/Storm.svg",
//       },
//       {
//         name: "Sun-fog.svg",
//         path: "/media/icons/stockholm/Weather/Sun-fog.svg",
//       },
//       {
//         name: "Sun.svg",
//         path: "/media/icons/stockholm/Weather/Sun.svg",
//       },
//       {
//         name: "Suset1.svg",
//         path: "/media/icons/stockholm/Weather/Suset1.svg",
//       },
//       {
//         name: "Suset2.svg",
//         path: "/media/icons/stockholm/Weather/Suset2.svg",
//       },
//       {
//         name: "Temperature-empty.svg",
//         path: "/media/icons/stockholm/Weather/Temperature-empty.svg",
//       },
//       {
//         name: "Temperature-full.svg",
//         path: "/media/icons/stockholm/Weather/Temperature-full.svg",
//       },
//       {
//         name: "Temperature-half.svg",
//         path: "/media/icons/stockholm/Weather/Temperature-half.svg",
//       },
//       {
//         name: "Thunder-night.svg",
//         path: "/media/icons/stockholm/Weather/Thunder-night.svg",
//       },
//       {
//         name: "Thunder.svg",
//         path: "/media/icons/stockholm/Weather/Thunder.svg",
//       },
//       {
//         name: "Umbrella.svg",
//         path: "/media/icons/stockholm/Weather/Umbrella.svg",
//       },
//       {
//         name: "Wind.svg",
//         path: "/media/icons/stockholm/Weather/Wind.svg",
//       },
//     ],
//   },
// ];
