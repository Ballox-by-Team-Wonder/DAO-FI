import React from "react";

export function Internationalization() {
  return <>Internationalization</>;
}
