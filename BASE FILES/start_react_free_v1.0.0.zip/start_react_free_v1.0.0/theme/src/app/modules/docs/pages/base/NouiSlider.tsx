import React from "react";

export function NouiSlider() {
  return <>noUISlider</>;
}
