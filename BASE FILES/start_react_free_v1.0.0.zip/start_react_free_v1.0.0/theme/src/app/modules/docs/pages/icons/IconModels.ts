export interface DItem {
  name: string;
  path: string;
}

export interface DList {
  name: string;
  items: Array<DItem>;
}